/*
 * kernel.c: Kernel main (entry) function
 *
 * Author: Group Member 1 <email address>
 *         Group Member 2 <email address>
 * Date:   The current time & date
 */

int main(int argc, char *argv[]) {
	/* Needs more code. */

	return -255;
}
